function FlowLab_Verification_Tests
% Run from MATLAB Command Window: FlowLab_Verification_Tests
% Checks ideal-gas solver against independent analytical relations.
g=1.4; R=287.05; P0=100*6894.757293; T0=300;
Dt=.010; De=Dt*sqrt(2.63671875); Di=.029;
L1=(Di-Dt)/2/tand(20);L2=(De-Dt)/2/tand(10);
x=[linspace(0,L1,150), L1+linspace(0,L2,150)];
x=unique(x);r=interp1([0 L1 L1+L2],[Di Dt De]/2,x);
A=pi*r.^2; At=pi*Dt^2/4;
% Test 1: ideally expanded M=2.5 nozzle
Me=2.5; c=(g-1)/2; Pe=P0/(1+c*Me^2)^(g/(g-1));
s=FlowLab_IdealGasNozzleSolver(x,A,P0,T0,Pe,g,R,'CD nozzle');
check(abs(s.M(end)-Me)<.003,'Ideal exit Mach');
check(abs(s.Pexit-Pe)/Pe<.003,'Ideal exit pressure');
check(s.massResidual<1e-5,'Ideal mass conservation');
mdotIdeal=At*P0*sqrt(g/(R*T0))*(2/(g+1))^((g+1)/(2*(g-1)));
check(abs(s.mdot-mdotIdeal)/mdotIdeal<.002,'Choked mass flow');
% Test 2: unchoked CD flow matches back pressure
s=FlowLab_IdealGasNozzleSolver(x,A,P0,T0,.99*P0,g,R,'CD nozzle');
check(contains(s.regime,'Unchoked'),'Unchoked regime');
check(abs(s.Pexit-.99*P0)/(.99*P0)<1e-5,'Unchoked exit pressure');
check(max(s.M)<1,'Unchoked subsonic everywhere');
check(s.massResidual<1e-5,'Unchoked mass conservation');
% Test 3: internal normal shock at intermediate back pressure
Mse=2.5;
Pse=P0/(1+c*Mse^2)^(g/(g-1));
PshockExit=Pse*(1+2*g/(g+1)*(Mse^2-1));
Pmid=(s.Pchoke+PshockExit)/2;
s=FlowLab_IdealGasNozzleSolver(x,A,P0,T0,Pmid,g,R,'CD nozzle');
check(contains(s.regime,'internal normal shock'),'Internal shock regime');
check(isfinite(s.shockX) && s.shockX>L1 && s.shockX<x(end),'Shock inside divergent section');
check(abs(s.Pexit-Pmid)/Pmid<.003,'Shock solution matches back pressure');
check(s.massResidual<1e-5,'Shock mass conservation');
% Test 4: choked converging nozzle, exit Mach 1
xc=linspace(0,.04,150);Ac=pi*(linspace(Di,Dt,150)/2).^2;
s=FlowLab_IdealGasNozzleSolver(xc,Ac,P0,T0,.2*P0,g,R,'Converging nozzle');
check(abs(s.M(end)-1)<1e-6,'Converging sonic exit');
check(s.massResidual<1e-5,'Converging mass conservation');
fprintf('\nAll Flow Lab ideal-gas verification tests PASSED.\n');
fprintf('Note: these are equation-verification tests, not experimental validation.\n');
end
function check(ok,name)
if ~ok,error('FAILED: %s',name);end
fprintf('PASS: %s\n',name);
end
