function sol = FlowLab_IdealGasNozzleSolver(x,A,P0,T0,Pb,g,R,geometry)
% Quasi-1D calorically-perfect-gas nozzle with optional internal normal shock.
% x [m], A [m^2], P0/Pb [Pa absolute], T0 [K]. No viscous/heat losses.
% geometry: 'CD nozzle' or 'Converging nozzle'.
validateattributes(x,{'double'},{'vector','real','finite'});
validateattributes(A,{'double'},{'vector','real','finite','positive'});
assert(numel(x)==numel(A) && numel(A)>2 && all(diff(x)>0),'Invalid axial mesh');
assert(P0>Pb && Pb>0 && T0>0 && g>1 && R>0,'Invalid thermodynamic inputs');
x=x(:)'; A=A(:)'; n=numel(A); [At,it]=min(A); Ae=A(end);
if strcmp(geometry,'Converging nozzle')
    assert(abs(Ae-At)/At<1e-8,'Converging nozzle minimum area must be at exit');
elseif strcmp(geometry,'CD nozzle')
    assert(it>1 && it<n && Ae>At,'CD nozzle requires an interior throat');
else
    error('Unsupported geometry');
end
c=(g-1)/2; e=g/(g-1);
% Choking threshold: limiting wholly-subsonic solution at sonic throat.
Mlim=flMach(Ae/At,g,false);
PbChoke=P0/(1+c*Mlim^2)^e;
P02=P0; shockX=NaN;
if Pb>=PbChoke*(1-1e-10)
    % Entirely subsonic, matched to imposed back pressure.
    Me=sqrt(2/(g-1)*((P0/Pb)^((g-1)/g)-1));
    Ast=Ae/flAreaMach(Me,g);
    assert(Ast<=At*(1+1e-7),'Subsonic branch is inconsistent with throat area');
    M=arrayfun(@(aa)flMach(aa/Ast,g,false),A);
    regime='Unchoked subsonic';
elseif strcmp(geometry,'Converging nozzle')
    M=arrayfun(@(aa)flMach(aa/At,g,false),A);
    regime='Choked converging';
else
    % Ideal fully supersonic downstream branch and shock-at-exit threshold.
    Msuper=flMach(Ae/At,g,true);
    PeIso=P0/(1+c*Msuper^2)^e;
    PeShockExit=PeIso*(1+2*g/(g+1)*(Msuper^2-1));
    if Pb>PeShockExit*(1+1e-10)
        % Internal normal shock: locate it so predicted exit static P=Pb.
        low=x(it); high=x(end);
        for k=1:75
            mid=(low+high)/2;
            [pex,~]=shockExitPressure(mid,x,A,it,At,Ae,P0,g);
            % Shock farther downstream -> lower exit pressure.
            if pex>Pb, low=mid; else, high=mid; end
        end
        shockX=(low+high)/2;
        [~,P02]=shockExitPressure(shockX,x,A,it,At,Ae,P0,g);
        As=interp1(x,A,shockX,'linear');
        M1=flMach(As/At,g,true);
        M2=sqrt((1+c*M1^2)/(g*M1^2-c));
        Ast2=As/flAreaMach(M2,g);
        M=zeros(1,n); P0profile=P0*ones(1,n);
        for j=1:n
            if j<=it, M(j)=flMach(A(j)/At,g,false);
            elseif x(j)<shockX, M(j)=flMach(A(j)/At,g,true);
            else, M(j)=flMach(A(j)/Ast2,g,false); P0profile(j)=P02;
            end
        end
        regime='Choked, internal normal shock';
    else
        M=zeros(1,n);
        for j=1:n
            M(j)=flMach(A(j)/At,g,j>it);
        end
        if Pb>PeIso*1.01
            regime='Choked, overexpanded (external adjustment)';
        elseif Pb<PeIso*.99
            regime='Choked, underexpanded (external adjustment)';
        else
            regime='Choked, ideally expanded';
        end
    end
end
if ~exist('P0profile','var'),P0profile=P0*ones(1,n);end
T=T0./(1+c*M.^2);
P=P0profile./(1+c*M.^2).^e;
rho=P./(R*T);
V=M.*sqrt(g*R*T);
mdot=rho(1)*A(1)*V(1);
% Conservation diagnostics: in an internal-shock case the discontinuity is
% represented by adjacent samples, with total pressure loss downstream.
mdotLocal=rho.*A.*V;
residual=max(abs(mdotLocal-mdot))/max(mdot,eps);
sol=struct('M',M,'P',P,'T',T,'rho',rho,'V',V,'mdot',mdot,...
    'regime',regime,'shockX',shockX,'P02',P02,'Pback',Pb,...
    'Pexit',P(end),'Pchoke',PbChoke,'massResidual',residual);
end

function [Pe,P02]=shockExitPressure(xs,x,A,it,At,Ae,P0,g)
As=interp1(x,A,xs,'linear');
M1=flMach(As/At,g,true);
c=(g-1)/2; e=g/(g-1);
M2=sqrt((1+c*M1^2)/(g*M1^2-c));
P1=P0/(1+c*M1^2)^e;
P2=P1*(1+2*g/(g+1)*(M1^2-1));
P02=P2*(1+c*M2^2)^e;
Ast2=As/flAreaMach(M2,g);
Me=flMach(Ae/Ast2,g,false);
Pe=P02/(1+c*Me^2)^e;
end
function ar=flAreaMach(M,g)
ar=(1./M).*((2/(g+1)).*(1+(g-1).*M.^2/2)).^((g+1)/(2*(g-1)));
end
function M=flMach(ar,g,sup)
if ar<1-1e-8,error('Invalid A/A* < 1');end
if abs(ar-1)<1e-9,M=1;return;end
if sup
    lo=1;hi=2;
    while flAreaMach(hi,g)<ar,hi=hi*2;end
    for k=1:65
        mid=(lo+hi)/2;
        if flAreaMach(mid,g)<ar,lo=mid;else,hi=mid;end
    end
else
    lo=1e-12;hi=1;
    for k=1:65
        mid=(lo+hi)/2;
        if flAreaMach(mid,g)>ar,lo=mid;else,hi=mid;end
    end
end
M=(lo+hi)/2;
end
